## Welcome

Everyone is welcome to contribute code via pull requests, to file issues on GitHub

## Developing for markdown_widget

To develop for markdown_widget, you need fork `dev` branch and submit pull requests based on it
