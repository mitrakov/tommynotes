## 0.2.2+5

- compatibility with Flutter 3

## 0.2.0+3

- add support for linux

## 0.1.2+2

- longer pub description

## 0.1.2+1

- fix for macOS flipped content views

## 0.1.2

- fix native context menu positioning regression

## 0.1.1+2

- windows implementation

## 0.1.0

- macOS implementation
