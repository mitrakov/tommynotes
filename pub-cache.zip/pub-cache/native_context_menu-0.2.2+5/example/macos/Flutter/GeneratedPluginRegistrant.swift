//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import native_context_menu

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  NativeContextMenuPlugin.register(with: registry.registrar(forPlugin: "NativeContextMenuPlugin"))
}
